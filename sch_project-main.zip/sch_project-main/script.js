const header = document.querySelectorAll('header');
console.log(header);
alert("doldd");